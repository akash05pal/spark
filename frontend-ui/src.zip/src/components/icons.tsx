import type { SVGProps } from "react";
import { Gem } from 'lucide-react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
   <Gem {...props} />
  );
}
