
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-competitor-insights.ts';
